#!/system/bin/sh

export GCCHOME="/system/gcc"
export GCCPATH=$GCCHOME/bin:$GCCHOME/arm-linux-androideabi/bin:$GCCHOME/libexec/
export PATH=$PATH:$GCCHOME:$GCCPATH

#chmod 744 /system/gcc/bin/*
#chmod 744 /system/gcc/arm-linux-androideabi/bin/*
#chmod 744 /system/gcc/libexec/gcc/arm-linux-androideabi/4.8.2/cc1
#chmod 744 /system/gcc/libexec/gcc/arm-linux-androideabi/4.8.2/cc1plus
#chmod 744 /system/gcc/libexec/gcc/arm-linux-androideabi/4.8.2/collect2
#chmod 744 /system/gcc/libexec/gcc/arm-linux-androideabi/4.8.2/plugin/gengtype


